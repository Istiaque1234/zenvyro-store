export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
}

export interface Category {
  id: string;
  name: string;
  image: string;
  iconName?: string;
}
