import { Product, Category } from './types';

export const categories: Category[] = [
  { id: '1', name: 'Premium Cases', image: 'https://images.unsplash.com/photo-1603313011101-320f26a4f6f6?auto=format&fit=crop&q=80&w=800' },
  { id: '2', name: 'Audio & Earbuds', image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800' },
  { id: '3', name: 'Power & Cables', image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=800' },
  { id: '4', name: 'Screen Protection', image: 'https://images.unsplash.com/photo-1541814389659-009ab97459b7?auto=format&fit=crop&q=80&w=800' },
];

export const products: Product[] = [
  {
    id: 'p1',
    name: 'ZENVYRO Carbon Fiber Case',
    category: 'Premium Cases',
    price: 49.99,
    originalPrice: 59.99,
    image: 'https://images.unsplash.com/photo-1611791484670-ce19b801d192?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 124,
    isNew: true,
  },
  {
    id: 'p2',
    name: 'ZenBuds Pro Active Noise Cancelling',
    category: 'Audio & Earbuds',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 89,
  },
  {
    id: 'p3',
    name: 'MagSafe Wireless Charger Stand',
    category: 'Power & Cables',
    price: 39.99,
    image: 'https://images.unsplash.com/photo-1622445270947-30dd94c4ecce?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 210,
  },
  {
    id: 'p4',
    name: 'Liquid Silicone Slim Case',
    category: 'Premium Cases',
    price: 24.99,
    image: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&q=80&w=800',
    rating: 4.5,
    reviews: 342,
  },
  {
    id: 'p5',
    name: 'Braided Fast Charging Cable (2M)',
    category: 'Power & Cables',
    price: 19.99,
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=800',
    rating: 4.6,
    reviews: 156,
  },
  {
    id: 'p6',
    name: 'Tempered Glass Privacy Shield',
    category: 'Screen Protection',
    price: 29.99,
    image: 'https://images.unsplash.com/photo-1541814389659-009ab97459b7?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 88,
    isNew: true,
  },
];
