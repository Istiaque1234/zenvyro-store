import { ShoppingBag, Search, Menu, User } from 'lucide-react';
import { motion } from 'motion/react';

export default function Navbar() {
  return (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button className="p-2 -ml-2 text-gray-900 hover:text-gray-600 transition-colors">
              <Menu className="w-5 h-5" />
            </button>
          </div>

          {/* Logo */}
          <div className="flex-shrink-0 flex items-center justify-center md:justify-start flex-1 md:flex-none">
            <a href="#" className="font-display font-bold text-2xl tracking-tighter">
              ZENVYRO
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-sm font-medium text-gray-900 hover:text-gray-500 transition-colors">Shop</a>
            <a href="#" className="text-sm font-medium text-gray-900 hover:text-gray-500 transition-colors">Categories</a>
            <a href="#" className="text-sm font-medium text-gray-900 hover:text-gray-500 transition-colors">New Arrivals</a>
            <a href="#" className="text-sm font-medium text-gray-900 hover:text-gray-500 transition-colors">About</a>
          </div>

          {/* Right Icons */}
          <div className="flex items-center space-x-4 md:space-x-6">
            <button className="text-gray-900 hover:text-gray-600 transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <button className="hidden md:block text-gray-900 hover:text-gray-600 transition-colors">
              <User className="w-5 h-5" />
            </button>
            <button className="text-gray-900 hover:text-gray-600 transition-colors relative">
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-1.5 -right-1.5 bg-black text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                2
              </span>
            </button>
          </div>

        </div>
      </div>
    </motion.nav>
  );
}
