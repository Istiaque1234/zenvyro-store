import { motion } from 'motion/react';
import { products } from '../data';
import { ShoppingBag, Star } from 'lucide-react';

export default function FeaturedProducts() {
  return (
    <section className="py-24 bg-white" id="shop">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl font-display font-bold tracking-tight text-gray-900">Featured Releases</h2>
            <p className="mt-2 text-gray-500 text-lg">The latest and greatest from ZENVYRO.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <div className="relative rounded-2xl overflow-hidden bg-gray-100 aspect-square mb-4">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                />
                {product.isNew && (
                  <div className="absolute top-4 left-4">
                    <span className="bg-white text-black text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wide">
                      New
                    </span>
                  </div>
                )}
                
                {/* Hover Add to Cart */}
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                  <button className="w-full bg-white text-black hover:bg-black hover:text-white border border-transparent font-medium py-3 px-4 rounded-xl flex items-center justify-center transition-colors shadow-lg">
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    Add to Cart
                  </button>
                </div>
              </div>
              
              <div className="px-1">
                <div className="flex items-center space-x-1 mb-1.5">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium text-gray-700">{product.rating}</span>
                  <span className="text-sm text-gray-400">({product.reviews})</span>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1 line-clamp-1">{product.name}</h3>
                <p className="text-sm text-gray-500 mb-2">{product.category}</p>
                <div className="flex items-center space-x-2">
                  <span className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-400 line-through">${product.originalPrice.toFixed(2)}</span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <button className="inline-flex items-center justify-center px-8 py-4 border border-gray-300 text-base font-medium rounded-full text-gray-900 bg-white hover:bg-gray-50 transition-colors">
            Load More Products
          </button>
        </div>
      </div>
    </section>
  );
}
