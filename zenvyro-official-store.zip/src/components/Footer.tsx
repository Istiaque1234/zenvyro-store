import { ArrowRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="lg:col-span-1">
            <a href="#" className="font-display font-bold text-2xl tracking-tighter block mb-4">
              ZENVYRO
            </a>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              Premium mobile accessories designed for the modern individual. Elevate your everyday carry with our curated collection.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Shop</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Premium Cases</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Audio & Earbuds</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Power & Cables</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Screen Protection</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">New Arrivals</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Support</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">FAQ</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Shipping & Returns</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Track Order</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Warranty</a></li>
              <li><a href="#" className="text-gray-500 hover:text-black transition-colors text-sm">Contact Us</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Stay Connected</h4>
            <p className="text-gray-500 text-sm mb-4">Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
            <form className="flex">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 min-w-0 px-4 py-2 text-sm border border-gray-300 rounded-l-lg focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
              />
              <button 
                type="submit" 
                className="px-4 py-2 bg-black text-white rounded-r-lg hover:bg-gray-800 transition-colors"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
          
        </div>
        
        <div className="border-t border-gray-100 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; 2026 ZENVYRO OFFICIAL STORE. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-black transition-colors text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-black transition-colors text-sm">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
