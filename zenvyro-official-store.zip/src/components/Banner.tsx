import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export default function Banner() {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-3xl overflow-hidden bg-black text-white"
        >
          <div className="absolute inset-0">
            <img 
              src="https://images.unsplash.com/photo-1558234320-007db1885b5e?auto=format&fit=crop&q=80&w=1600" 
              alt="Promo background" 
              className="w-full h-full object-cover opacity-40"
            />
          </div>
          <div className="relative z-10 px-6 py-16 sm:py-24 sm:px-12 lg:px-16 flex flex-col items-center text-center">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold tracking-tight mb-4">
              The Minimalist Collection
            </h2>
            <p className="max-w-2xl text-lg sm:text-xl text-gray-300 mb-8">
              Discover our new range of ultra-slim, protective cases crafted from aerospace-grade aramid fiber.
            </p>
            <a href="#shop" className="inline-flex items-center px-8 py-4 rounded-full bg-white text-black font-semibold hover:bg-gray-100 transition-colors">
              Explore Collection <ArrowRight className="ml-2 w-5 h-5" />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
